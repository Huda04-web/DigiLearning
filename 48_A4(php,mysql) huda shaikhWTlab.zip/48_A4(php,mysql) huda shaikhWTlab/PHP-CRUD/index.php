
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>PHP CRUD</title>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
    </head>
    <style align="center">
        
        
        th{
            color:black;
        }
        
       /* div{
            background-image:url('https://ecobnb.com/blog/app/uploads/sites/3/2018/09/londra.jpg');
             background-repeat: no-repeat;
        }*/
        
        #customers {
        font-family: Arial, Helvetica, sans-serif;
        border-collapse: collapse;
        width: 100%;
        }
      
       div{
            tetx-align:center;
        }
        
      
        .center1 {
        margin: auto;
        width: 20%;
        border: 1px solid powderblue;
        padding: 10px;
        }
        
        
      
</style>
    <body>
                <p style="font-size:20px;margin-left: 1050px;color:#990000">Originator: HUDA SHAIKH</p>
                <p style="font-size:30px;text-align:center;color: #191966;">Adhaar ID System</p>

        <?php
        echo "<img style='background-color:none;margin-left:500px;margin-right:500px;margin-top:-40px;margin-bottom:10px;' src='adhar.png' >";  
        ?>
        </br>
        <?php require_once 'process.php'; ?>
        
        <?php
            if(isset($_SESSION['message'])): ?>
        
        <div class="alert alert-<?=$_SESSION['msg_type']?>">
        
            <?php
                echo $_SESSION['message'];
                unset($_SESSION['message']);
            ?>
        </div>
        <?php endif ?>
            
        <div class="container">
        <?php
        $mysqli = new mysqli('localhost','root','','crud') or die(mysqli_error($mysqli));
        $result = $mysqli->query("select * from data") or die($mysqli->error);
          //pre_r($result);
          ?>
        
        <div class="row justify-content-center">
            <table class="table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Address</th> 
                        <th>Adhaar ID</th>
                        <th colspan="2">Action</th>
                    </tr>
                </thead>
                
                <?php
                    while($row = $result->fetch_assoc()):?>
                
                <tr>
                    <td><?php echo $row['name'];?></td>
                    <td><?php echo $row['location'];?></td>
                    <td><?php echo $row['balance'];?></td>
                    
                    <td>
                        <a href="index.php?edit=<?php echo $row['id']; ?>"
                           class="btn btn-info">Edit</a>
                           <a href="process.php?delete=<?php echo $row['id']; ?>"
                              class="btn btn-danger">Delete</a>
                              
                           <!--<a href="process.php?transfer=<?php echo $row['id']; ?>"
                              class="btn btn-primary">Transfer</a>
                            -->
                    </td>
  
                </tr>
            <?php endwhile; ?>
            </table>
        </div>
         
        <?php
        function pre_r($array){
            echo '<pre>';
            print_r($array);
            echo '</pre>';
        }
        
        
        ?>
        <hr>
        <div class="row justify-content-center">
        <form action="process.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="form-group">
                <center><label style="color:">Name</label></center>
            <input type="text" name="name" class="form-control center1"
                   value="<?php echo $name; ?>" placeholder="Enter Your Name">
            
            </div>
            <div class="form-group">           
                <center><label style="color:">Location</label></center>
            <input type="text" name="location" class="form-control center1" 
                   value="<?php echo $location; ?>"  placeholder="Enter Your location">
            </div>
            <div class="form-group">
                    <center><label style="color:">Adhar ID</label></center>
                    <input type="text" name="balance" class="form-control center1" 
                     value="<?php echo $balance; ?>"  placeholder="Enter Your ID">
            </div>    
            <div class="form-group">
               <?php 
               if($update==true):
               ?>
             <center><button type="submit" class="btn btn-info" name="update">Update</button></center>

               <?php else: ?>
               
                <center><button type="submit" class="btn btn-primary" name="save">save</button></center>
                <?php endif; ?>
                
            </div>
            
        </form>
        </div>
        </div>
    </body>
</html>
